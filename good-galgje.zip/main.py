import random

foutcount = 0

fout0 = '''
___
'''
fout1 = '''
|
|
|
|___
'''
fout2 = '''
________
|
|
|
|___
'''
fout3 = '''
_______
|     |
|
|
|___
'''

fout4 = '''
_______
|     |
|     O
|
|___
'''
fout5 = '''
_______
|     |
|     O
|     |
|___
'''
fout6 = '''
_______
|     |
|     O
|     |/
|___
'''
fout7 = '''
_______
|     |
|     O
|    \|/
|___
'''
fout8 = '''
_______
|     |
|     O
|    \|/
|___ /
'''
fout9 = '''
_______
|     |
|     O
|    \|/
|___ / \
'''

fouten_lijst = [fout0, fout1, fout2, fout3, fout4, fout5, fout6, fout7, fout8, fout9]
woorden = ["aardappel", "foto", "galgje", "informatica", "appel", "nederland", "telefoon", "schoolwerk", "autoventilatieventieldopjes", "kangeroe", "meervoudigepersoonlijkheidsstoornis", "aansprakelijkheidswaardevaststellingsveranderingen", "randomwoord", "stinksok"]

def printgalg():
  print(fouten_lijst[foutcount-2])

def print_welkom():
  print("Welkom bij")
  print(" ")
  print("  ___    __    __    ___   ____  ____ ")
  print(" / __)  /__\  (  )  / __) (_  _)( ___)")
  print("( (_-. /(__)\  )(__( (_-..-_)(   )__) ")
  print(" \___/(__)(__)(____)\___/\____) (____)")

def main():
  global foutcount
  global printgalg

  woord = random.choice(woorden)
  aantal_beurten = 11
  foutcount = 1
  print_welkom()
  gerade_letters = ''
  woord_geraden = False
  letters_in_woord = len(woord)
  print(woord)
  print("_" * letters_in_woord)
  
  while aantal_beurten > 0 and not woord_geraden:
    toonwoord = ''
    gerade_letter = input ('Raad een letter: ')
    gerade_letters += gerade_letter
    if gerade_letter == woord:
      print("je hebt het woord geraden")
      woord_geraden = True
    elif gerade_letter in woord:
      print("goedzo jou letter zit in het woord ")
      for char in woord:
        if char in gerade_letters:
          toonwoord = toonwoord + (char)
        else:
          toonwoord = toonwoord + ('_')
      print(toonwoord)
      #controleer of woord geraden is
      woord_geraden = True
      for char in woord:
        if char not in gerade_letters:
          woord_geraden = False
          break   
    elif aantal_beurten == 0:
      print("Je hangt")
    elif gerade_letter not in woord:  
      aantal_beurten -= 1
      foutcount = foutcount + 1
      printgalg()
      print(toonwoord)
    else:
      print("Je hebt blijkbaar iets verkeerds geraden probeer een kleine letter in te voeren")

main()






# while beurten > 0:          
#   letters_niet_geraden = 0             
#   toonwoord=''
 
#   for char in woord:      
#     if char in gerade_letters:    
#       toonwoord = toonwoord + (char)

#     else:
#       toonwoord = toonwoord + ('_')     
#       foutcount += 1

#     print (toonwoord)
#     print('Al gegokte letters:' + gerade_letters)

#     if foutcount == 0:
#       print("je hebt verloren")
#       print("prtfrft")
#       break

#     print(woord)
#     gerade_letter = input ('Raad een letter: ') 

#     gerade_letters += gerade_letter                    

#     if gerade_letter not in woord:  
#       beurten -= 1
#       printgalg()
    
#     if beurten == 0:           
#       print ('...')